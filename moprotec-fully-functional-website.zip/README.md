# MOPROTEC Web

A static, responsive, privacy-conscious public website for MOPROTEC.

## Run locally

Open `index.html` directly, or use any static server:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Deploy

The site contains no server-side dependency. It can be deployed to GitHub Pages, Azure Static Web Apps, Cloudflare Pages, Netlify, or any conventional static host.

## Security

The repository is intended to use CodeQL for:
- `actions` with `build-mode: none`
- `javascript-typescript` with `build-mode: autobuild` once the repository contains a Node/JS/TS build project

No secrets are stored in the website source. Contact uses a `mailto:` link.

## IP / legal notice

The website describes products and project claims for informational purposes. Copyright, trademark, patent and other rights depend on applicable law and facts. The site does not itself create or certify legal rights.
