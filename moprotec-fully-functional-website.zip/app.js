const root=document.documentElement;
const themeBtn=document.getElementById("themeBtn");
const saved=localStorage.getItem("moprotec-theme");
if(saved==="light") root.dataset.theme="light";
themeBtn.addEventListener("click",()=>{
  const light=root.dataset.theme==="light";
  root.dataset.theme=light?"":"light";
  localStorage.setItem("moprotec-theme",light?"dark":"light");
  themeBtn.textContent=light?"☾":"☀";
});
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.getElementById("name").value.trim();
  const email=document.getElementById("email").value.trim();
  const message=document.getElementById("message").value.trim();
  const subject=encodeURIComponent("MOPROTEC website inquiry");
  const body=encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);
  document.getElementById("formStatus").textContent="Opening your email application…";
  window.location.href=`mailto:apoochmorley@protonmail.com?subject=${subject}&body=${body}`;
});
