# Copilot Internet Access & Firewall — Operational Guide (Organization & Repository)

This document contains GitHub Copilot firewall guidance and an emergency quick‑actions checklist to protect against AI-agent-driven exfiltration. Follow these steps when performing an incident lockdown.

Overview
- Configure firewall settings from Organization -> Settings -> Copilot -> Internet access.
- Important org settings: Enable firewall, enable recommended allowlist, disable allow repository custom rules (if you want centralized control).
- Repository settings can be set only when org-level is “Let repositories decide.” For incident response set repo-level firewall to Enabled and disallow custom rules.

Immediate UI actions (quick)
1. Organization level:
   - GitHub -> Organization -> Settings -> Copilot -> Internet access
   - Enable firewall: Enabled
   - Recommended allowlist: Enabled
   - Allow repository custom rules: Disabled
   - Under Organization custom allowlist -> add vetted domains/URLs (package registries, internal artifact hosts only).

2. Repository level (for affected repo):
   - Repo -> Settings -> Copilot -> Internet access
   - Enable firewall: Enabled
   - Recommended allowlist: Enabled
   - Allow repository custom rules: Disabled (unless a pre‑approved exception exists)

3. When Copilot firewall blocks an attempted request a warning is added to the PR or as a comment with blocked address and attempted command — preserve that PR/comment as evidence.

Limitations and important notes
- Firewall covers only processes started by Copilot agent in the GitHub Actions appliance; MCP servers and pre-configured setup steps may not be protected.
- Treat the firewall as a strong mitigation layer but not the single solution — combine it with secret rotation, access revocation, and forensics.

Emergency quick checklist (for custodians)
1. Preserve evidence: snapshot repo; collect commit SHAs and logs.
2. Apply org-level firewall settings (see above).
3. For the affected repo: set to private; disable repo custom rules.
4. Rotate all repository and registry secrets/tokens.
5. Disable CI/CD pipelines and freeze deployments.
6. Create GPG-signed provenance snapshot and encrypt for escrow.
7. Notify counsel and hosting providers; send DMCA if content is published.

Automation option
- Use the provided scripts/enforce_copilot_firewall.sh and scripts/enforce_all_systems_lockdown.sh to automate the org+repo changes and snapshot creation (these require gh CLI and appropriate permissions; see scripts for placeholders and usage).

Further reading
- Copilot allowlist reference: https://docs.github.com/en/copilot/reference/copilot-allowlist-reference
- Using GitHub Copilot code review: https://docs.github.com/en/copilot/how-tos/use-copilot-agents/request-a-code-review/use-code-review#customizing-copilot-code-reviews-environment