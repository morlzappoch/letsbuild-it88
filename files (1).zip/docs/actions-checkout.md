# actions/checkout — Official usage guide

This document describes the recommended usage and security considerations for the `actions/checkout` step in GitHub Actions workflows.

Purpose
- `actions/checkout` fetches the repository content to the runner workspace so subsequent steps can read, build, test, or modify the repository.

Recommended pinning
- For reproducibility pin to an exact release (e.g. `actions/checkout@v7.0.1`).
- To receive backward-compatible fixes automatically pin to the major tag (e.g. `actions/checkout@v7`).

Key inputs
- `token` (string): token used to fetch private repos. Default: `\${{ github.token }}`.
- `ref` (string): branch, tag, or SHA to check out (e.g. `refs/heads/main`).
- `fetch-depth` (integer): `0` = full history; default `1` = shallow. Use `0` when you need full history, tags, or git describe.
- `submodules` (boolean or "recursive"): update submodules. Use `"recursive"` for nested submodules.
- `lfs` (boolean): download Git LFS files when true.
- `path` (string): destination path (defaults to the workspace root).
- `persist-credentials` (boolean): whether to persist credentials in `.git/config`. Set `false` to avoid exposing tokens to later steps.

Security notes
- Workflows triggered by forked pull requests run with restricted secrets — do not rely on secrets or write-access tokens in those runs.
- If you need to perform actions that require secrets for PRs from forks, consider using `pull_request_target` with extreme caution (it runs code from the default branch).
- Avoid persisting credentials when not needed (`persist-credentials: false`) to reduce accidental token exposure.

Common examples
- Basic checkout
```yaml
- name: Checkout
  uses: actions/checkout@v7.0.1