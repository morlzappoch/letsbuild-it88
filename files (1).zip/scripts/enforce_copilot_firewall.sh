#!/usr/bin/env bash
# enforces Copilot Internet Access settings at organization and repository level using gh CLI
# REQUIREMENTS:
# - gh CLI installed and authenticated with a token that has admin:org and repo scope
# - Replace placeholders ORG and REPO before running, or pass as args: ./enforce_copilot_firewall.sh ORG REPO

set -euo pipefail

ORG="${1:-YOUR_ORG}"
REPO="${2:-YOUR_REPO}"
GITHUB_TOKEN="${GITHUB_TOKEN:-}"  # best set in environment; gh CLI will use it if logged in
# Settings we enforce
ENABLE_FIREWALL="enabled"
RECOMMENDED_ALLOWLIST="enabled"
ALLOW_REPO_CUSTOM_RULES="disabled"

echo "Enforcing Copilot Internet Access settings for org=${ORG} repo=${REPO}"

# Organization-level settings (gh api to the GraphQL/REST endpoint)
echo "Setting organization Internet access settings..."
gh api --method PATCH "/orgs/${ORG}/copilot/internet-access" -f enable_firewall="${ENABLE_FIREWALL}" -f recommended_allowlist="${RECOMMENDED_ALLOWLIST}" -f allow_repository_custom_rules="${ALLOW_REPO_CUSTOM_RULES}"

# Add vetted domains to org custom allowlist (example list; customize)
declare -a VETTED_DOMAINS=("packages.contoso.corp" "registry.npmjs.org" "registry.yarnpkg.com" "repo.mycompany.internal")
for domain in "${VETTED_DOMAINS[@]}"; do
  echo "Adding org allowlist entry: ${domain}"
  gh api --method POST "/orgs/${ORG}/copilot/internet-access/allowlist" -f entry="${domain}"
done

# Repository-level override (set repo to inherit or explicitly set)
echo "Setting repository Copilot Internet Access settings..."
# Note: endpoint path may vary by API version — validate with gh api help in your environment
gh api --method PATCH "/repos/${ORG}/${REPO}/copilot/internet-access" -f enable_firewall="${ENABLE_FIREWALL}" -f recommended_allowlist="${RECOMMENDED_ALLOWLIST}" -f allow_repository_custom_rules="${ALLOW_REPO_CUSTOM_RULES}"

echo "Copilot firewall settings enforced for ${ORG}/${REPO}. Verify in the GitHub UI or gh api responses."