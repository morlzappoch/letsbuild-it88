#!/usr/bin/env bash
# High-level lockdown script across "All Systems".
# WARNING: This script contains destructive or disruptive steps (rotating/revoking keys, privatizing repos).
# Review and test in a safe environment. Run only with full authorization.

set -euo pipefail

ORG="${1:-YOUR_ORG}"
REPO="${2:-YOUR_REPO}"
GPG_KEY_ID="${3:-YOUR_GPG_KEY_ID}"
SNAPSHOT_TAG="vprovenance-$(date -u +%Y%m%dT%H%M%SZ)"

if [ -z "${GITHUB_TOKEN:-}" ]; then
  echo "Set GITHUB_TOKEN env var or ensure gh CLI is authenticated."
fi

echo "Starting All-Systems Lockdown for ${ORG}/${REPO} at $(date -u)."

# 1) Preserve evidence: mirror clone
echo "Creating mirror clone..."
git clone --mirror "https://github.com/${ORG}/${REPO}.git" "/tmp/${REPO}-mirror-$(date -u +%s)"
COMMIT_SHA=$(git -C "/tmp/${REPO}-mirror-$(date -u +%s)" rev-parse --short HEAD 2>/dev/null || echo "unknown")
echo "Mirror created, commit SHA: ${COMMIT_SHA}"

# 2) Privatize repo (UI or API)
echo "Setting repository visibility to private to limit public exposure..."
gh api --method PATCH "/repos/${ORG}/${REPO}" -f visibility="private" || echo "Failed to set private - check permissions"

# 3) Revoke deploy keys & rotate tokens (placeholders)
echo "Listing deploy keys (will revoke all — confirm before running in prod)..."
gh api "/repos/${ORG}/${REPO}/keys" | jq -r '.[] | [.id, .key] | @tsv' || true
# To revoke uncomment and run with care:
# gh api --method DELETE "/repos/${ORG}/${REPO}/keys/<KEY_ID>"

echo "NOTE: Rotating tokens and revoking OAuth apps must be done per provider (GitHub Apps, cloud provider keys). Review logs and revoke suspected credentials immediately."

# 4) Freeze CI/CD (example: disable GitHub Actions workflows)
echo "Disabling GitHub Actions workflows in repository..."
for wf in $(gh api -X GET "/repos/${ORG}/${REPO}/actions/workflows" | jq -r '.workflows[].id'); do
  echo "Disabling workflow id=${wf}"
  gh api --method PUT "/repos/${ORG}/${REPO}/actions/workflows/${wf}/disable" || true
done

# 5) Enforce Copilot firewall via script (calls enforce_copilot_firewall.sh)
echo "Enforcing Copilot firewall settings..."
./scripts/enforce_copilot_firewall.sh "${ORG}" "${REPO}"

# 6) Add Ownership Schedule & transcript and create GPG-signed tag
echo "Adding Ownership Schedule and transcript to repo and creating signed tag..."
git clone "https://github.com/${ORG}/${REPO}.git" "/tmp/${REPO}-working-$(date -u +%s)"
cd "/tmp/${REPO}-working-$(date -u +%s)"
mkdir -p docs
# Copy your ownership schedule and transcript into docs/ before running (or adjust paths)
cp /path/to/Ownership_Schedule_and_Declaration_Morley_Apooch_2026-09-02.md docs/ || true
cp /path/to/claude_transcript_2026-04-07.txt docs/ || true
git add docs/*.md || true
if git diff --cached --quiet; then
  git commit --allow-empty -m "Provenance snapshot: add Ownership Schedule & AI transcript"
else
  git commit -m "Provenance snapshot: add Ownership Schedule & AI transcript"
fi
git tag -a "${SNAPSHOT_TAG}" -m "Provenance snapshot ${SNAPSHOT_TAG}"
if [ "${GPG_KEY_ID}" != "YOUR_GPG_KEY_ID" ]; then
  git tag -s "${SNAPSHOT_TAG}" -u "${GPG_KEY_ID}" -m "Signed provenance snapshot"
fi
git push origin --tags
echo "Snapshot tag ${SNAPSHOT_TAG} created and pushed (verify)."

# 7) Create encrypted archive for escrow (calls master_lock_shamir.sh)
echo "Creating encrypted escrow archive (run master_lock_shamir.sh locally to generate shares and encrypted archive)."

echo "All-systems lockdown script finished. Next: contact legal counsel and forensics immediately. Preserve the chain-of-custody record of every action."