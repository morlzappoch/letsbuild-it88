#!/usr/bin/env bash
# Create a signed snapshot, symmetric encrypt it, and split the passphrase into Shamir shares.
# REQUIREMENTS: openssl, gpg, ssss (or install via package manager), git
# USAGE: ./master_lock_shamir.sh ORG REPO N_SHARES THRESHOLD
set -euo pipefail

ORG="${1:-YOUR_ORG}"
REPO="${2:-YOUR_REPO}"
N="${3:-5}"
T="${4:-3}"
OUT_DIR="${5:-/tmp/provenance_$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "${OUT_DIR}"

echo "Preparing provenance snapshot for ${ORG}/${REPO}"
git clone --mirror "https://github.com/${ORG}/${REPO}.git" "${OUT_DIR}/mirror"
COMMIT_SHA=$(git -C "${OUT_DIR}/mirror" rev-parse --short HEAD || echo "unknown")
SNAP_TAR="${OUT_DIR}/provenance_${COMMIT_SHA}.tar.gz"
git -C "${OUT_DIR}/mirror" archive --format=tar --prefix="provenance_${COMMIT_SHA}/" HEAD | gzip > "${SNAP_TAR}"

# Sign the archive with GPG (detached signature). User must have GPG configured locally.
echo "Creating detached signature (if GPG configured)..."
if command -v gpg >/dev/null 2>&1; then
  gpg --output "${SNAP_TAR}.sig" --detach-sign "${SNAP_TAR}" || echo "gpg signing failed or not configured"
fi

# Generate random symmetric passphrase
MASTER_PASSPHRASE_FILE="${OUT_DIR}/master_passphrase.txt"
openssl rand -base64 48 > "${MASTER_PASSPHRASE_FILE}"
chmod 600 "${MASTER_PASSPHRASE_FILE}"

# Symmetrically encrypt the snapshot
ENCRYPTED_SNAPSHOT="${SNAP_TAR}.gpg"
gpg --symmetric --cipher-algo AES256 --batch --passphrase-file "${MASTER_PASSPHRASE_FILE}" --output "${ENCRYPTED_SNAPSHOT}" "${SNAP_TAR}"

# Split the passphrase into Shamir shares (ssss required)
if command -v ssss-split >/dev/null 2>&1; then
  echo "Splitting passphrase into ${N} shares with threshold ${T}..."
  # ssss-split prints shares to stdout; redirect into files
  ssss-split -t "${T}" -n "${N}" < "${MASTER_PASSPHRASE_FILE}" | awk '{print > "'"${OUT_DIR}"'/share_"NR".txt"}'
  echo "Shares created in ${OUT_DIR}"
else
  echo "ssss-split not found. Install 'ssss' or use 'ssss-split' to generate Shamir shares. Passphrase saved at ${MASTER_PASSPHRASE_FILE}"
fi

echo "Encrypted snapshot: ${ENCRYPTED_SNAPSHOT}"
echo "Do NOT transmit shares or ${MASTER_PASSPHRASE_FILE} insecurely. Distribute shares to custodians per the distribution plan."