#!/usr/bin/env bash
set -euo pipefail

# === USER CONFIGURE THESE ===
REPO_PATH="${1:-.}"                        # repo root; default current dir
DOCS_PATH="docs"
OWNERSHIP_FILE="${DOCS_PATH}/Ownership_Schedule_and_Declaration_Morley_Apooch_2026-09-02.md"
TRANSCRIPT_FILE="${DOCS_PATH}/claude_transcript_2026-04-07.txt"
GPG_KEY_ID="[YOUR_GPG_KEY_ID]"            # set to your GPG key id for -u when signing
TAG_NAME="v2026-04-07-provenance"
COMMIT_MESSAGE="Provenance snapshot: Anthropic Claude assist (2026-04-07) + Ownership schedule"
ARCHIVE_NAME="provenance_snapshot_2026-04-07.tar.gz"
ENCRYPTED_ARCHIVE="${ARCHIVE_NAME}.gpg"
SPDX_LICENSE="MIT"
SPDX_HEADER="/*\n * Copyright (c) 2026 Morley Apooch\n * Project: [PROJECT]\n * Created with assistance from Anthropic Claude on 2026-04-07.\n * Author direction/architecture session: ~45 minutes.\n * SPDX-License-Identifier: ${SPDX_LICENSE}\n */\n\n"

# File globs to add SPDX header to; edit as needed
FILE_EXTENSIONS=("*.py" "*.js" "*.ts" "*.go" "*.java" "*.c" "*.cpp" "*.rb" "*.sh")

echo "Running provenance snapshot script in repo: ${REPO_PATH}"
cd "${REPO_PATH}"

# Create docs path if missing and ensure ownership & transcript exist
mkdir -p "${DOCS_PATH}"
if [ ! -f "${OWNERSHIP_FILE}" ]; then
  echo "Creating stub Ownership file at ${OWNERSHIP_FILE}"
  cat > "${OWNERSHIP_FILE}" <<'EOF'
[Paste the full Ownership_Schedule_and_Declaration_Morley_Apooch_2026-09-02.md contents here before running]
EOF
fi

if [ ! -f "${TRANSCRIPT_FILE}" ]; then
  echo "Please place the AI transcript at ${TRANSCRIPT_FILE} before running to include it in the snapshot."
fi

# 1) Insert SPDX header at top of matching source files (if not present)
echo "Inserting SPDX headers into files..."
for ext in "${FILE_EXTENSIONS[@]}"; do
  for f in $(git ls-files -- "${ext}" 2>/dev/null || true); do
    if [ -f "$f" ]; then
      if ! grep -q "SPDX-License-Identifier" "$f"; then
        echo -e "${SPDX_HEADER}$(cat "$f")" > "$f"
        git add "$f"
        echo "Added SPDX header to $f"
      fi
    fi
  done
done

# 2) Add docs files to git and commit snapshot
git add "${OWNERSHIP_FILE}" || true
git add "${TRANSCRIPT_FILE}" || true

if git diff --cached --quiet; then
  echo "No staged changes to commit (headers may already be applied). Creating an empty commit to mark snapshot."
  git commit --allow-empty -m "${COMMIT_MESSAGE}"
else
  git commit -m "${COMMIT_MESSAGE}"
fi

# 3) Create and sign tag (requires GPG configured)
echo "Creating and signing tag ${TAG_NAME} (GPG key: ${GPG_KEY_ID})..."
git tag -a "${TAG_NAME}" -m "Provenance: Anthropic Claude (2026-04-07)" || true
# If you want to GPG-sign:
if [ "${GPG_KEY_ID}" != "[YOUR_GPG_KEY_ID]" ]; then
  git tag -s "${TAG_NAME}" -m "Signed provenance snapshot" -u "${GPG_KEY_ID}"
fi

# 4) Push commits and tags
echo "Pushing commits and tags to origin..."
git push origin --follow-tags

# 5) Create an encrypted archive for escrow
echo "Creating signed tarball and encrypting..."
git rev-parse --verify HEAD >/dev/null
COMMIT_SHA=$(git rev-parse --short HEAD)
tar czf "${ARCHIVE_NAME}" --files-from /dev/null
# Add tracked files of the snapshot (Ownership doc, transcript, and repo snapshot)
git archive --format=tar --prefix="provenance_${COMMIT_SHA}/" HEAD | gzip > "${ARCHIVE_NAME}"
# Sign the archive (detached)
gpg --output "${ARCHIVE_NAME}.sig" --detach-sign "${ARCHIVE_NAME}"
# Encrypt for your GPG key (replace with recipient key or symmetric)
gpg --output "${ENCRYPTED_ARCHIVE}" --encrypt --recipient "${GPG_KEY_ID}" "${ARCHIVE_NAME}"

echo "Snapshot created: ${ARCHIVE_NAME}, signature: ${ARCHIVE_NAME}.sig, encrypted: ${ENCRYPTED_ARCHIVE}"
echo "Keep copies in at least two secure locations and deposit escrow if desired."

# Print instructions
echo
echo "Next: create a GitHub release off the signed tag and attach ${ENCRYPTED_ARCHIVE} or reference the commit SHA: ${COMMIT_SHA}"