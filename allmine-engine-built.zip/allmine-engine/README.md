# ALLMINE Search Matrix

A small Node.js web service with a browser search UI and a Wikipedia-backed search endpoint.

## Run

```bash
npm test
npm start
```

Then open http://localhost:5000

## Deployment

Set `ALLOWED_ORIGIN` to the exact public frontend origin when deploying behind a separate frontend. `PORT` is supplied by most hosts automatically.

## Ownership notice

© 2026 Morley Moses Apooch. All Rights Reserved. This repository is marked UNLICENSED. Third-party data sources remain governed by their own terms.
