/** ALLMINE SEARCH MATRIX ENGINE — © 2026 Morley Moses Apooch. All Rights Reserved. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const PORT = Number(process.env.PORT || 5000);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const PUBLIC = path.join(__dirname, 'public');
function cors(res, origin){
  const allowed = ALLOWED_ORIGIN === '*' || !origin || origin === ALLOWED_ORIGIN;
  res.setHeader('Access-Control-Allow-Origin', allowed ? (ALLOWED_ORIGIN === '*' ? '*' : origin) : 'null');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type');
  return allowed;
}
function send(res,status,type,body){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(body);}
async function searchWikipedia(query){
  const u = new URL('https://en.wikipedia.org/w/api.php');
  u.search = new URLSearchParams({action:'query',list:'search',srsearch:query,format:'json',origin:'*',srlimit:'10'});
  const r = await fetch(u,{headers:{'User-Agent':'ALLMINE-Search-Matrix/1.0'}});
  if(!r.ok) throw new Error(`Upstream HTTP ${r.status}`);
  const data = await r.json();
  return (data.query?.search || []).map(x=>({title:x.title,snippet:x.snippet.replace(/<[^>]*>/g,''),url:`https://en.wikipedia.org/wiki/${encodeURIComponent(x.title.replace(/ /g,'_'))}`}));
}
const server=http.createServer(async(req,res)=>{
  const origin=req.headers.origin;
  if(!cors(res,origin)){return send(res,403,'application/json',JSON.stringify({error:'Origin blocked'}));}
  if(req.method==='OPTIONS') return send(res,204,'text/plain','');
  const url=new URL(req.url,`http://${req.headers.host}`);
  try{
    if(req.method==='GET' && url.pathname==='/api/health') return send(res,200,'application/json',JSON.stringify({ok:true,service:'ALLMINE Search Matrix',signature:'ALLMINE-PROPRIETARY-V1',timestamp:new Date().toISOString()}));
    if(req.method==='GET' && url.pathname==='/api/search'){
      const query=(url.searchParams.get('q')||'').trim();
      if(!query) return send(res,400,'application/json',JSON.stringify({error:'Search query required.'}));
      const results=await searchWikipedia(query);
      return send(res,200,'application/json',JSON.stringify({success:true,owner:'Morley Moses Apooch',signature:'ALLMINE-PROPRIETARY-V1',copyright:'© 2026 Morley Moses Apooch. All Rights Reserved.',timestamp:new Date().toISOString(),results}));
    }
    if(req.method==='GET'){
      const requested=url.pathname==='/'?'/index.html':url.pathname;
      const file=path.normalize(path.join(PUBLIC,requested));
      if(!file.startsWith(PUBLIC)) return send(res,403,'text/plain','Forbidden');
      if(fs.existsSync(file) && fs.statSync(file).isFile()){
        const ext=path.extname(file); const type={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json'}[ext]||'application/octet-stream';
        return send(res,200,type,fs.readFileSync(file));
      }
    }
    send(res,404,'application/json',JSON.stringify({error:'Not found'}));
  }catch(e){console.error(e);send(res,502,'application/json',JSON.stringify({error:'Search engine temporarily unavailable.'}));}
});
server.listen(PORT,()=>console.log(`[ALLMINE] running on port ${PORT}`));
